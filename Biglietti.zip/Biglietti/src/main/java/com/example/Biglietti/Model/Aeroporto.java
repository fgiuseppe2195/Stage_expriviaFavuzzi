package com.example.Biglietti.Model;

import javax.persistence.*;

@Entity
public class Aeroporto {

    @Id
    @Column(name = "codiceaeroporto")
    private String codiceAeroporto;

    @Column(name = "citta")
    private String citta;

    @Column(name = "nome")
    private String nome;

    @Column(name = "numeropiste")
    private int numeroPiste;

    @Column(name = "nazionalita")
    private String nazionalita;

    public String getCodiceAeroporto() {
        return codiceAeroporto;
    }

    public void setCodiceAeroporto(String codiceAeroporto) {
        this.codiceAeroporto = codiceAeroporto;
    }

    public String getCitta() {
        return citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroPiste() {
        return numeroPiste;
    }

    public void setNumeroPiste(int numeroPiste) {
        this.numeroPiste = numeroPiste;
    }

    public String getNazionalita() {
        return nazionalita;
    }

    public void setNazionalita(String nazionalita) {
        this.nazionalita = nazionalita;
    }
}
