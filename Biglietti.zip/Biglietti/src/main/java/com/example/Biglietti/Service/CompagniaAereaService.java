package com.example.Biglietti.Service;

import com.example.Biglietti.Model.CompagniaAerea;
import com.example.Biglietti.Repository.CompagniaAereaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CompagniaAereaService {

    @Autowired
    private CompagniaAereaRepository compagniaAereaRepository;


    @Transactional
    public CompagniaAerea getCompagniaAerea(String id) {
        return compagniaAereaRepository.findById(id).orElse(null);
    }

    @Transactional
    public void inserisciCompagniaAerea(CompagniaAerea compagniaAerea) {
        compagniaAereaRepository.save(compagniaAerea);
    }

    @Transactional
    public void modificaCompagniaAerea(String id, CompagniaAerea compagniaAerea) {
        CompagniaAerea existingCompagniaAerea = compagniaAereaRepository.findById(id).orElse(null);
        if (existingCompagniaAerea != null) {
            // Effettua le modifiche necessarie
            compagniaAereaRepository.save(existingCompagniaAerea);
        }
    }
}
