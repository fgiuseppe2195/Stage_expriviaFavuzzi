package com.example.Biglietti.Service;

import com.example.Biglietti.Model.Prenotazione;
import com.example.Biglietti.Repository.PrenotazioneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PrenotazioneService {

    @Autowired
    private PrenotazioneRepository prenotazioneRepository;

    @Transactional
    public Prenotazione getPrenotazione(Long id) {
        return prenotazioneRepository.findById(id).orElse(null);
    }

    @Transactional
    public void inserisciPrenotazione(Prenotazione prenotazione) {
        prenotazioneRepository.save(prenotazione);
    }

    @Transactional
    public void modificaPrenotazione(Long id, Prenotazione prenotazione) {
        Prenotazione existingPrenotazione = prenotazioneRepository.findById(id).orElse(null);
        if (existingPrenotazione != null) {
            existingPrenotazione.setCodiceCliente(prenotazione.getCodiceCliente());
            existingPrenotazione.setNumeroVolo(prenotazione.getNumeroVolo());
            existingPrenotazione.setDataPrenotazione(prenotazione.getDataPrenotazione());
            existingPrenotazione.setDataViaggio(prenotazione.getDataViaggio());
            existingPrenotazione.setCostoFatturato(prenotazione.getCostoFatturato());
            prenotazioneRepository.save(existingPrenotazione);
        }
    }
}
