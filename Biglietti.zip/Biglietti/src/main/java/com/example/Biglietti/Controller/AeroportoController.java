package com.example.Biglietti.Controller;

import com.example.Biglietti.Model.Aeroporto;
import com.example.Biglietti.Service.AeroportoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/aeroporti")
public class AeroportoController {

    @Autowired
    private AeroportoService aeroportoService;

    @GetMapping("/{id}")
    public ResponseEntity<Aeroporto> visualizzaDettagliAeroporto(@PathVariable String id) {
        Aeroporto aeroporto = aeroportoService.getAeroporto(id);
        if (aeroporto != null) {
            return ResponseEntity.ok(aeroporto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Void> inserisciAeroporto(@RequestBody Aeroporto aeroporto) {
        aeroportoService.inserisciAeroporto(aeroporto);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> modificaAeroporto(@PathVariable String id, @RequestBody Aeroporto aeroporto) {
        aeroportoService.modificaAeroporto(id, aeroporto);
        return ResponseEntity.ok().build();
    }
}
