package com.example.Biglietti.Service;

import com.example.Biglietti.Model.Aeroporto;
import com.example.Biglietti.Repository.AeroportoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AeroportoService {

    @Autowired
    private AeroportoRepository aeroportoRepository;

    // Metodi del servizio per la gestione degli aeroporti

    @Transactional
    public Aeroporto getAeroporto(String id) {
        return aeroportoRepository.findById(id).orElse(null);
    }

    @Transactional
    public void inserisciAeroporto(Aeroporto aeroporto) {
        aeroportoRepository.save(aeroporto);
    }

    @Transactional
    public void modificaAeroporto(String id, Aeroporto aeroporto) {
        Aeroporto existingAeroporto = aeroportoRepository.findById(id).orElse(null);
        if (existingAeroporto != null) {
            // Effettua le modifiche necessarie
            aeroportoRepository.save(existingAeroporto);
        }
    }
}
