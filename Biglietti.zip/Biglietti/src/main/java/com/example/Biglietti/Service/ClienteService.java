package com.example.Biglietti.Service;

import com.example.Biglietti.Model.Cliente;
import com.example.Biglietti.Repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Transactional
    public Cliente getCliente(Long id) {
        return clienteRepository.findById(id).orElse(null);
    }

    @Transactional
    public void inserisciCliente(Cliente cliente) {
        clienteRepository.save(cliente);
    }

    @Transactional
    public void modificaCliente(Long id, Cliente cliente) {
        Cliente existingCliente = clienteRepository.findById(id).orElse(null);
        if (existingCliente != null) {
            // Copia i valori dal cliente ricevuto come parametro all'oggetto esistente
            existingCliente.setNome(cliente.getNome());
            existingCliente.setIndirizzo(cliente.getIndirizzo());
            existingCliente.setNumerotelefono(cliente.getNumerotelefono());
            existingCliente.setEta(cliente.getEta());

            // Salva l'oggetto esistente con i nuovi valori
            clienteRepository.save(existingCliente);
        }
    }
}
