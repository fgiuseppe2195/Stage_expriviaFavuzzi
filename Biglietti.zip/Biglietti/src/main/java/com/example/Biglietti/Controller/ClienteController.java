package com.example.Biglietti.Controller;

import com.example.Biglietti.Model.Cliente;
import com.example.Biglietti.Service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/clienti")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping("/{id}")
    public ResponseEntity<Cliente> visualizzaDettagliCliente(@PathVariable Long id) {
        Cliente cliente = clienteService.getCliente(id);
        if (cliente != null) {
            return ResponseEntity.ok(cliente);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Void> inserisciCliente(@RequestBody Cliente cliente) {
        clienteService.inserisciCliente(cliente);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> modificaCliente(@PathVariable Long id, @RequestBody Cliente cliente) {
        clienteService.modificaCliente(id, cliente);
        return ResponseEntity.ok().build();
    }
}
