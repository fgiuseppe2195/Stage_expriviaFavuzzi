package com.example.Biglietti.Controller;

import com.example.Biglietti.Model.CompagniaAerea;
import com.example.Biglietti.Service.CompagniaAereaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/compagnieAeree")
public class CompagniaAereaController {

    @Autowired
    private CompagniaAereaService compagniaAereaService;

    @GetMapping("/{id}")
    public ResponseEntity<CompagniaAerea> visualizzaDettagliCompagniaAerea(@PathVariable String id) {
        CompagniaAerea compagniaAerea = compagniaAereaService.getCompagniaAerea(id);
        if (compagniaAerea != null) {
            return ResponseEntity.ok(compagniaAerea);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Void> inserisciCompagniaAerea(@RequestBody CompagniaAerea compagniaAerea) {
        compagniaAereaService.inserisciCompagniaAerea(compagniaAerea);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> modificaCompagniaAerea(@PathVariable String id, @RequestBody CompagniaAerea compagniaAerea) {
        compagniaAereaService.modificaCompagniaAerea(id, compagniaAerea);
        return ResponseEntity.ok().build();
    }

}
