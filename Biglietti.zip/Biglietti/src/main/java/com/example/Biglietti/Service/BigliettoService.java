package com.example.Biglietti.Service;

import com.example.Biglietti.Model.Prenotazione;

import java.time.DayOfWeek;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class BigliettoService {

    private static final double COSTO_BASE = 100.0;
    private static final int POSTI_TOTALI = 50;
    private static final int SCAGLIONE = 10;
    private static final double AUMENTO_PERCENTUALE = 0.1;

    private static final Map<DayOfWeek, Double> AUMENTO_GIORNI_FESTIVI;

    static {
        AUMENTO_GIORNI_FESTIVI = new HashMap<>();
        AUMENTO_GIORNI_FESTIVI.put(DayOfWeek.SUNDAY, 0.1);
        // Aggiungi altri giorni festivi se necessario
    }

    public double calcolaCostoBiglietto(Prenotazione prenotazione) {
        int postiPrenotati = prenotazione.getNumeroPosti(); // Assumo che tu abbia un attributo getNumeroPosti() nella classe Prenotazione
        Date dataPrenotazione = prenotazione.getDataPrenotazione();

        double costoBase = COSTO_BASE;
        int numeroScaglioni = postiPrenotati / SCAGLIONE;

        // Calcola l'aumento basato sugli scaglioni
        for (int i = 0; i < numeroScaglioni; i++) {
            costoBase *= (1 + AUMENTO_PERCENTUALE);
        }

        // Verifica se la data è un giorno festivo
        if (AUMENTO_GIORNI_FESTIVI.containsKey(dataPrenotazione.getDay())) {
            costoBase *= (1 + AUMENTO_GIORNI_FESTIVI.get(dataPrenotazione.getDay()));
        }

        return costoBase;
    }
}
