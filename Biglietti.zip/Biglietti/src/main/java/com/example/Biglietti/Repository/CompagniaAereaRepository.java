package com.example.Biglietti.Repository;

import com.example.Biglietti.Model.CompagniaAerea;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompagniaAereaRepository extends JpaRepository<CompagniaAerea, String> {

}
