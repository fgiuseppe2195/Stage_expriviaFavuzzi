package com.example.Biglietti.Model;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Prenotazione {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "numeroprenotazione")
    private Long numeroPrenotazione;


    @Column(name = "codicecliente")
    private Long codiceCliente;

    @Column(name = "numerovolo")
    private int numeroVolo;

    @Column(name = "dataprenotazione")
    private Date dataPrenotazione;

    @Column(name = "dataviaggio")
    private Date dataViaggio;

    @Column(name = "costofatturato")
    private double costoFatturato;

    public Long getNumeroPrenotazione() {
        return numeroPrenotazione;
    }

    public void setNumeroPrenotazione(Long numeroPrenotazione) {
        this.numeroPrenotazione = numeroPrenotazione;
    }

    public Long getCodiceCliente() {
        return codiceCliente;
    }

    public void setCodiceCliente(Long codiceCliente) {
        this.codiceCliente = codiceCliente;
    }

    public int getNumeroVolo() {
        return numeroVolo;
    }

    public void setNumeroVolo(int numeroVolo) {
        this.numeroVolo = numeroVolo;
    }

    public Date getDataPrenotazione() {
        return dataPrenotazione;
    }

    public void setDataPrenotazione(Date dataPrenotazione) {
        this.dataPrenotazione = dataPrenotazione;
    }

    public Date getDataViaggio() {
        return dataViaggio;
    }

    public void setDataViaggio(Date dataViaggio) {
        this.dataViaggio = dataViaggio;
    }

    public double getCostoFatturato() {
        return costoFatturato;
    }

    public void setCostoFatturato(double costoFatturato) {
        this.costoFatturato = costoFatturato;
    }
    @Transient
    public int getNumeroPosti() {
        // Implementa la logica per ottenere il numero di posti
        // In base ai dati disponibili nella tua classe
        return 0;  // Aggiorna questa implementazione con la logica corretta
    }
}
