package com.example.Biglietti.Controller;

import com.example.Biglietti.Model.Prenotazione;
import com.example.Biglietti.Service.PrenotazioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/prenotazioni")
public class PrenotazioneController {

    @Autowired
    private PrenotazioneService prenotazioneService;

    @GetMapping("/{id}")
    public ResponseEntity<Prenotazione> visualizzaDettagliPrenotazione(@PathVariable Long id) {
        Prenotazione prenotazione = prenotazioneService.getPrenotazione(id);
        if (prenotazione != null) {
            return ResponseEntity.ok(prenotazione);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Void> inserisciPrenotazione(@RequestBody Prenotazione prenotazione) {
        prenotazioneService.inserisciPrenotazione(prenotazione);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> modificaPrenotazione(@PathVariable Long id, @RequestBody Prenotazione prenotazione) {
        prenotazioneService.modificaPrenotazione(id, prenotazione);
        return ResponseEntity.ok().build();
    }
}
