package com.example.Biglietti.Model;

import javax.persistence.*;

@Entity
@Table(name = "Compagnia_Aerea")
public class CompagniaAerea {

    @Id
    @Column(name = "nomecompagnia")
    private String nomeCompagnia;

    @Column(name = "sede")
    private String sede;

    public String getNomeCompagnia() {
        return nomeCompagnia;
    }

    public void setNomeCompagnia(String nomeCompagnia) {
        this.nomeCompagnia = nomeCompagnia;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }
}
