package com.example.Biglietti.Repository;

import com.example.Biglietti.Model.Aeroporto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AeroportoRepository extends JpaRepository<Aeroporto, String> {

}
