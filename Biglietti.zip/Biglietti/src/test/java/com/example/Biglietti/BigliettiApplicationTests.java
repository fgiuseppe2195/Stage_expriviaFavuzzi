package com.example.Biglietti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BigliettiApplicationTests {

	@Test
	void contextLoads() {
	}

}
